const express = require("express")
const BookModel = require("../models/books")

const routes = express.Router()

//Get All Books
routes.get("/books", (req, res) => {
    BookModel.find()
    .then(books => {
    res.status(200).send({
        status: true,
        message: "Successfully fetched all books",
        count: books.length,
        data: new Date(),
        books
    })
    })
    .catch(err => {
        res.status(500).send({
            status: false,
            message: err.message
        })
})
})

//Add NEW Book
routes.post("/books", async (req, res) => {
    const bookData = req.body
    const newBookModel = new BookModel(bookData)
    try{
    const newBook = await newBookModel.save()

    res.send({
        status:true,
        message: "New Book Added",
        book: newBook
    })
}catch(err){
    res.status(500).send({
        status: false,
        message:err.message
    })
}
})

// Update existing Book By Id
routes.put("/book/:bookid", (req, res) => {
    BookModel.findByIdAndUpdate(req.params.bookid, req.body, { new: true })
    .then((book) => {
        if (book) {
            res.status(200).send({
                message: "Updated Successfully",
                updated_book: book
            })
        } else {
            res.status(404).send({ message: "Book not found" })
        }
    })
    .catch((err) => {
        res.status(500).send({ message: err.message })
    })
})


//Delete Book By ID
routes.delete("/book/:bookid", (req, res) => {
    BookModel.findByIdAndDelete(req.params.bookid)
    .then((book) => {
        if (book) {
            res.status(200).send({
                message: "Book Deleted Successfully",
                deleted_book: book
            })
        } else {
            res.status(404).send({ message: "Book not found" })
        }
    })
    .catch((err) => {
        res.status(500).send({ message: err.message })
    })

    //res.send({message: "Delete Book By ID"})
})

//Get Book By ID
routes.get("/book/:bookid", (req, res) => {

    BookModel.findById(req.params.bookid)
    .then((book) => {
        if(book){
            res.send(book)
        }else {
            res.status(404).send({message: "Book not found"})
        }
    }).catch((err) => {
        res.status(500).send({message: err.message})
    })

    //res.send({message: "Get Book By ID"})
})

//Get All Books in sorted order
routes.get("/books/sort", async (req, res) => {
    //res.send({message: "Get Book By ID"})
})


module.exports = routes